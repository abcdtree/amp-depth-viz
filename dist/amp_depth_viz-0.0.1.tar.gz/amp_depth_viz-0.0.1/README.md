# amp-depth-viz
visualise amplicon genome coverage by bokeh using mosdepth output
